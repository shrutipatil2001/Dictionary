#include<stdio.h>
#include<stdlib.h>
#include"dictionary.h"
#include"stack.h"

int main(int argc, char *argv[])
{
    char *dict_file = "dictionary.txt";
    char *history_file = "recent.txt";
    init(dict_file,history_file);
    int ch = compare_op(argv[1]);
    switch(ch){
        case 1:{
            if(argc > 2)
                view(argv[2]);
            else
                view("??");
        }
        break;
        case 2:{
            insert(argv[2],argv[3]);
        }
        break;
        case 3:
            search(argv[2]);
        break;
        case 4:{
            remove_word(argv[2]);
        }
        break;
        case 5:
            suggest(argv[2]);
        break;
        case 6:
            show_history();
        break;
        case 0:
            //history();
            printf("\n\n\t INVALID CHOICE....Try Again...!!");
        break;
    }
    store_back(dict_file);
    history(ch,argv[2]);
    return 0;
}
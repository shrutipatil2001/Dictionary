#ifndef stack_h
#define stack_h
#include"dictionary.h"

typedef struct node{
    dict *d;
    struct node* next;
}node;
typedef struct stack{
    node *dt;
}stack;

void init_stack(stack *s);
void push(stack *s, dict *n);
dict* pop(stack *s);
int isEmpty(stack s);

#endif
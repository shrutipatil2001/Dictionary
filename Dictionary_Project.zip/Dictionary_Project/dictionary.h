#ifndef dictionary_h
#define dictionary_h

typedef struct dict {
  struct dict *left,*right;
  char word[50],meaning[50];
}dict;

typedef struct dict* dictionary;

void insert(char word[],char meaning[]);                            // insert word in tree
void init(char *filename1, char *filename2);                              // to initialise tree
void view(char ch[]);                              // to view whole tree (all words)  
void search(char word[]);                            // to search a word
void remove_word(char word[]);                       // to remove word from dictionary
int compare_op(char op[]);
void store_back(char *filename);
void history(int t,char word[50]);
void suggest(char word[50]);
void show_history();

#endif

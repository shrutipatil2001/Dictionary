#include"dictionary.h"
#include"stack.c"
#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include<time.h>

const int alphabet = 26;
char dict_file[50];
char history_file[50];
dictionary Page[26];
int hashfunction(char ch);
void view_all(dictionary d);               // view words in order
int compare(char word[50], char nword[50]);
int compare_pre(char word[50],char pre[50]);
char* gettime();
void suggestion(char word[50],char pword[50]); 



void init(char *filename1, char *filename2) {
    // initialise all trees
    for(int i = 0; i < 26; i++){
        Page[i] = NULL;
    }
    strcpy(dict_file,filename1);
    FILE *fp = fopen(filename1,"r");
    char word[50],meaning[50];
    if(!fp)
        printf("\n\t Error in opening...!!");
    while(fscanf(fp,"%s %s\n",&word,&meaning) != EOF)
        insert(word,meaning);
    fclose(fp);
    strcpy(history_file,filename2);
    return;
}

void insert(char word[50], char meaning[50])
{
    // inserting a new word into dictionary
    // new word created
    dict *n = (dict *)malloc(sizeof(dict));    

    int flag = 0;
    dict *ptr,*par;    // traversing pointers 
    ptr = Page[hashfunction(word[0])];   // finding the location of tree in hash table
    strlwr(word);
    strlwr(meaning);
    if(n){
        // node initialisation
        n->left = NULL;
        n->right = NULL;
        strcpy(n->word,word);
        strcpy(n->meaning,meaning);
    }
    
    if(ptr == NULL){
        Page[hashfunction(word[0])] = n; 
       // store_back(fname);
        return;      // tree is empty thus, first node added 
    }   
    else{
        while(ptr != NULL ){
            // traverse tree to find place for word to insert
            par = ptr;
            if(compare(n->word,ptr->word) > 0)
                ptr = ptr->right;
            else if(compare(n->word,ptr->word) < 0)
                ptr = ptr->left;
            else if(compare(n->word,ptr->word) == 0){
                flag = 1;
                break;
            }
        }
    }
    if(flag == 0 && ptr == NULL){
        if(compare(par->word,n->word) == 1)
            par->left = n;
        else if(compare(par->word,n->word) == -1)
            par->right = n;
    }
   // store_back(fname);
    return;
}
    
int compare(char word[50], char nword[50]){
    int i,j,flag;
    i = 0;
    j = 0;
    while(word[i] != '\0' && nword[j] != '\0'){
        if(word[i] > nword[j]){
            flag = 1;
            break;
        }
        else if(nword[j] > word[i]){
            flag = -1;
            break;
        }
        else
            flag = 0;
        i++;
        j++;
    }
    return flag;
}

void view(char ch[5]){
    //char ch;
  //  printf("\n\t Press (Y/y) to view whole dictionary \n\t else enter (N/n) : ");
   // scanf(" %c",&ch);
    if(ch[0] == '?' && ch[1] == '?'){
        for(int i = 0; i < 26; i++){
            if(Page[i] != NULL)
                view_all(Page[i]);
        }
        return;
    }
    else{   
        view_all(Page[hashfunction(ch[0])]);
        return;
    }
    return;
}

void view_all(dictionary d){
    // inorder traversal L P R
    if(!d)
        return;
    dict *p = d;
    view_all(d->left);
    printf("\n%s ",d->word);
   // printf("<---->");
   // printf(" %s",p->meaning);
    view_all(d->right);
    return;
}

int hashfunction(char ch){
    // to find the location
    if(ch >= 65 && ch <= 90)
        return (ch-65);
    else if(ch >= 97 && ch <= 122)   
        return (ch-97);
}

void search(char word[50]){
    int flag = 0;
    dict *ptr;
    ptr = Page[hashfunction(word[0])];
    strlwr(word);
    while(ptr != NULL && flag == 0){
        if(compare(word,ptr->word) > 0)
            ptr = ptr->right;
        else if(compare(word,ptr->word) < 0)
            ptr = ptr->left;
        else if(compare(word,ptr->word) == 0){
            flag = 1;
            printf("\n ===> %s",ptr->meaning);
            break;
        }
    }
    if(flag == 0)
        printf("\n\tWord Not Found....!!");
    printf("\n\n You may also Search....\n");
    char tword[50];
    strcpy(tword,word);
    tword[2] = '\0';
    suggestion(word,tword);
    return;
}

int compare_op(char op[5]){
    if(op[0] == '-'){
        if(op[1] == 'v')
            return 1;
        else if(op[1] == 'i')
            return 2;
        else if(op[1] == 'f')
            return 3;
        else if(op[1] == 'r')
            return 4;
        else if(op[1] == 's')
            return 5;
        else if(op[1] == 'h')
            return 6;
        else 
            return 0;
    }
    else 
        return 0;
}

void store_back(char *filename){
    FILE *fp = fopen(filename,"w");
    if(!fp)
        printf("\n\t Error in opening...!!");
    stack s;
    init_stack(&s);
    for(int i = 0; i < 26; i++){
        dictionary d = Page[i];
        if(d != NULL){
            dict *p = d;
            while(p != NULL || s.dt != NULL){
                while(p != NULL){
                    push(&s,p);
                    p = p->left;
                }
                if(s.dt != NULL){
                    p = pop(&s);
                    fprintf(fp,"%s %s\n",p->word,p->meaning);
                    p = p->right;
                }
            }
        }
    }
    fclose(fp);
    return;
}

void remove_word(char word[50]){
    dict *d = Page[hashfunction(word[0])];
    if(d == NULL) // is tree empty?
        return;
    dict *q = NULL;
    dict *p = d;
    while(p){  //searching node that is to be deleted
        if(compare(p->word,word) == 0)
           break;
        else{
            q = p;
            if(compare(p->word,word) == -1)
                p = p->right;
            else if(compare(p->word,word) == 1)
                p = p->left;
        }
    }
        //p is NULL -> not found
        //p is not NULL -> Found

    if(p == NULL) 
        return;
    else{
        //is p a leaf node;
        if(p->left == NULL && p->right == NULL){
            //leaf node but it is root node also (onl one node in tree)
            if(q == NULL){
                Page[hashfunction(word[0])] = NULL;
               // store_back(fname);
                free(p);
                return;
            }
            //leaf node but not root
            if(q->left == p)
                q->left = NULL;
            else 
                q->right = NULL;
            //store_back(fname);
            free(p);    
            return;
        }
        //only one child but it is root and not leaf also
        if((p->left != NULL && p->right == NULL) || (p->left == NULL && p->right != NULL)){
            // p is root
            if(!q){
                if(p->left)
                    d = p->left;
                else
                    d = p->right;
            }
            else {
                // p is left of q
                if(q->left == p){
                    if(p->left)
                        q->left = p->left;
                    else if(p->right)
                        q->left = p->right;
                }  
                else{
                    if(p->left)
                        q->right = p->left;
                    else if(p->right)
                        q->right = p->right;
                }     
        }
        Page[hashfunction(word[0])] = d;
        //store_back(fname);
        free(p);
        return;
        }
        // node with two children
        dict *r, *s;
        r = NULL;
        s = p->left;
        while(s->right){
            r = s;
            s = s->right;
        }
        if(!r){
            r = p;
            do{
                strcpy(r->word,s->word);
                strcpy(r->meaning,s->meaning);
                r = s;
                s = s->left;
            }while(s->left);
            strcpy(r->word,s->word);
            strcpy(r->meaning,s->meaning);
          //  store_back(fname);
            free(s);
            r->left = NULL;
            return;
        }
        strcpy(p->word,s->word);
        strcpy(p->meaning,s->meaning);
        //store_back(fname);
        free(s);
        r->right = NULL;
        return;
    }
   // store_back(fname);
    return;
}

void suggest(char word[50]){
    stack s;
    init_stack(&s);
        dictionary d = Page[hashfunction(word[0])];
        if(d != NULL){
            dict *p = d;
            while(p != NULL || s.dt != NULL){
                while(p != NULL){
                    push(&s,p);
                    p = p->left;
                }
                if(s.dt != NULL){
                    p = pop(&s);
                    if(compare_pre(p->word,word) == 1)
                        printf("\n - %s",p->word);
                    p = p->right;
                }
            }
        }
    return;
}

void suggestion(char word[50],char tword[50]){
    stack s;
    init_stack(&s);
        dictionary d = Page[hashfunction(word[0])];
        if(d != NULL){
            dict *p = d;
            while(p != NULL || s.dt != NULL){
                while(p != NULL){
                    push(&s,p);
                    p = p->left;
                }
                if(s.dt != NULL){
                    p = pop(&s);
                    if(compare_pre(p->word,tword) == 1 && compare(p->word,word) != 0)
                        printf("\n - %s",p->word);
                    p = p->right;
                }
            }
        }
    return;
}

int compare_pre(char word[50],char pre[50]){
    int flag = 0;
    int i = 0;
    do{
        if(word[i] == pre[i])
            flag = 1;
        else 
            flag = 0;
        i++;
    }while(pre[i] != '\0' && flag == 1);
    return flag;
}

char* gettime(){
    time_t current;   
    time(&current);
    char *str = ctime(&current); 
    int j = 0;
    for(int i = 4; i < strlen(str); i++){
        str[j] = str[i];
        j++;
    }
    str[j] = '\0';
    return str;
}

void history(int t,char word[50]){
    FILE *fp = fopen(history_file,"a");
    char *mytime = gettime();
    if(t == 2)
        fprintf(fp,"inserted --> %s :%s",word,mytime);
    else if( t == 3)
        fprintf(fp,"searched --> %s :%s",word,mytime);
    else if(t == 4)
        fprintf(fp,"deleted --> %s :%s",word,mytime);
    else if(t == 5)
        fprintf(fp,"explored Suggestions for --> %s : %s",word,mytime);
    fclose(fp);
    return;
}

void show_history(){
    FILE *fp = fopen(history_file,"r");
    char line[500];
    while(!feof(fp)){
        fgets(line,500,fp);
        printf("\n\t %s",line);
    }
    fclose(fp);
    return;
}
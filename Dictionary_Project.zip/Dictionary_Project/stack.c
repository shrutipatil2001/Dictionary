#include<stdio.h>
#include<stdlib.h>
#include"dictionary.h"
#include"stack.h"


void init_stack(stack *s){
    s->dt = NULL;
}

void push(stack *s, dict *n){
    node *nn = (node*)malloc(sizeof(node));
    if(nn){
        nn->d = n;
        nn->next = NULL;
    }
    if(s->dt == NULL)
        s->dt = nn;
    else{
        nn->next = s->dt;
        s->dt = nn;
    }
    return;
}

dict* pop(stack *s){
    dict *p = NULL;
    node *q = s->dt;
    if(!isEmpty(*s)){
        p = q->d;
        s->dt = q->next;
        free(q);
    }
    return(p);
}

int isEmpty(stack s){
    if(s.dt == NULL)
        return 1;
    else
        return 0;
}
